"use client"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { FileText, TrendingUp, AlertTriangle, CheckCircle, Upload } from "lucide-react"

interface AnalysisData {
  overallScore: number
  strengths: string[]
  improvements: string[]
  keywords: string[]
  sections: {
    name: string
    score: number
    feedback: string
  }[]
}

interface ResumeAnalysisProps {
  fileName: string
  analysisData: AnalysisData
  resumeContent: string
  onNewUpload: () => void
}

export function ResumeAnalysis({ fileName, analysisData, resumeContent, onNewUpload }: ResumeAnalysisProps) {
  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-green-600"
    if (score >= 60) return "text-yellow-600"
    return "text-red-600"
  }

  const getScoreBg = (score: number) => {
    if (score >= 80) return "bg-green-100"
    if (score >= 60) return "bg-yellow-100"
    return "bg-red-100"
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Resume Analysis</h2>
          <p className="text-muted-foreground flex items-center gap-2">
            <FileText className="w-4 h-4" />
            {fileName}
          </p>
        </div>
        <Button variant="outline" onClick={onNewUpload}>
          <Upload className="w-4 h-4 mr-2" />
          Upload New Resume
        </Button>
      </div>

      {/* Overall Score */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold">Overall Score</h3>
          <div className={`text-3xl font-bold ${getScoreColor(analysisData.overallScore)}`}>
            {analysisData.overallScore}/100
          </div>
        </div>
        <Progress value={analysisData.overallScore} className="h-3 mb-2" />
        <p className="text-sm text-muted-foreground">
          {analysisData.overallScore >= 80
            ? "Excellent! Your resume is well-optimized."
            : analysisData.overallScore >= 60
              ? "Good foundation with room for improvement."
              : "Significant improvements needed for better results."}
        </p>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Strengths */}
        <Card className="p-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-green-600" />
            Strengths
          </h3>
          <div className="space-y-3">
            {analysisData.strengths.map((strength, index) => (
              <div key={index} className="flex items-start gap-2">
                <div className="w-1.5 h-1.5 bg-green-500 rounded-full mt-2 flex-shrink-0" />
                <p className="text-sm">{strength}</p>
              </div>
            ))}
          </div>
        </Card>

        {/* Improvements */}
        <Card className="p-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-yellow-600" />
            Areas for Improvement
          </h3>
          <div className="space-y-3">
            {analysisData.improvements.map((improvement, index) => (
              <div key={index} className="flex items-start gap-2">
                <div className="w-1.5 h-1.5 bg-yellow-500 rounded-full mt-2 flex-shrink-0" />
                <p className="text-sm">{improvement}</p>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Keywords */}
      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-blue-600" />
          Key Skills & Keywords
        </h3>
        <div className="flex flex-wrap gap-2">
          {analysisData.keywords.map((keyword, index) => (
            <Badge key={index} variant="secondary">
              {keyword}
            </Badge>
          ))}
        </div>
      </Card>

      {/* Section Analysis */}
      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4">Section-by-Section Analysis</h3>
        <div className="space-y-4">
          {analysisData.sections.map((section, index) => (
            <div key={index} className="space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="font-medium">{section.name}</h4>
                <div
                  className={`px-2 py-1 rounded text-sm font-semibold ${getScoreBg(section.score)} ${getScoreColor(section.score)}`}
                >
                  {section.score}/100
                </div>
              </div>
              <Progress value={section.score} className="h-2" />
              <p className="text-sm text-muted-foreground">{section.feedback}</p>
            </div>
          ))}
        </div>
      </Card>
    </div>
  )
}
