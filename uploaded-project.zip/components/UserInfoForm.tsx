"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { User, Mail, Phone, MapPin, Briefcase, Calendar } from "lucide-react"

interface UserInfo {
  name: string
  email: string
  phone: string
  currentRole: string
  targetRole: string
  experience: string
  location: string
}

interface UserInfoFormProps {
  onComplete: (userInfo: UserInfo) => void
}

export function UserInfoForm({ onComplete }: UserInfoFormProps) {
  const [formData, setFormData] = useState<UserInfo>({
    name: "",
    email: "",
    phone: "",
    currentRole: "",
    targetRole: "",
    experience: "",
    location: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onComplete(formData)
  }

  const handleChange = (field: keyof UserInfo, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const isFormValid = Object.values(formData).every((value) => value.trim() !== "")

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl p-8 bg-gradient-card shadow-medium border-0">
        <div className="text-center mb-8">
          <div className="w-16 h-16 mx-auto mb-4 bg-gradient-primary rounded-full flex items-center justify-center">
            <User className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold mb-2">Welcome to AI Resume Analyzer</h1>
          <p className="text-muted-foreground">Let's get to know you better to provide personalized insights</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name" className="flex items-center gap-2">
                <User className="w-4 h-4" />
                Full Name
              </Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => handleChange("name", e.target.value)}
                placeholder="John Doe"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email" className="flex items-center gap-2">
                <Mail className="w-4 h-4" />
                Email Address
              </Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => handleChange("email", e.target.value)}
                placeholder="john@example.com"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="phone" className="flex items-center gap-2">
                <Phone className="w-4 h-4" />
                Phone Number
              </Label>
              <Input
                id="phone"
                value={formData.phone}
                onChange={(e) => handleChange("phone", e.target.value)}
                placeholder="+1 (555) 123-4567"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="location" className="flex items-center gap-2">
                <MapPin className="w-4 h-4" />
                Location
              </Label>
              <Input
                id="location"
                value={formData.location}
                onChange={(e) => handleChange("location", e.target.value)}
                placeholder="San Francisco, CA"
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="currentRole" className="flex items-center gap-2">
              <Briefcase className="w-4 h-4" />
              Current Role
            </Label>
            <Input
              id="currentRole"
              value={formData.currentRole}
              onChange={(e) => handleChange("currentRole", e.target.value)}
              placeholder="Senior Software Engineer"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="targetRole" className="flex items-center gap-2">
              <Briefcase className="w-4 h-4" />
              Target Role
            </Label>
            <Input
              id="targetRole"
              value={formData.targetRole}
              onChange={(e) => handleChange("targetRole", e.target.value)}
              placeholder="Engineering Manager"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="experience" className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              Years of Experience
            </Label>
            <Select onValueChange={(value) => handleChange("experience", value)} required>
              <SelectTrigger>
                <SelectValue placeholder="Select experience level" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="0-1">0-1 years</SelectItem>
                <SelectItem value="2-3">2-3 years</SelectItem>
                <SelectItem value="4-6">4-6 years</SelectItem>
                <SelectItem value="7-10">7-10 years</SelectItem>
                <SelectItem value="10+">10+ years</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Button type="submit" className="w-full" disabled={!isFormValid}>
            Continue to Resume Upload
          </Button>
        </form>
      </Card>
    </div>
  )
}
