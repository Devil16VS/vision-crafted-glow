"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Download, FileText, ImageIcon, Share2, Palette, Layout, Zap } from "lucide-react"

interface ExportDialogProps {
  analysisData: any
  resumeContent: string
  fileName: string
  userInfo: any
}

export function ExportDialog({ analysisData, resumeContent, fileName, userInfo }: ExportDialogProps) {
  const [selectedTemplate, setSelectedTemplate] = useState("modern")
  const [exportFormat, setExportFormat] = useState("pdf")
  const [isExporting, setIsExporting] = useState(false)

  const templates = [
    {
      id: "modern",
      name: "Modern Professional",
      description: "Clean, ATS-friendly design with subtle colors",
      preview: "/modern-professional-resume.png",
      features: ["ATS Optimized", "Clean Layout", "Professional"],
    },
    {
      id: "creative",
      name: "Creative Impact",
      description: "Bold design for creative professionals",
      preview: "/creative-resume-template-with-colors.jpg",
      features: ["Eye-catching", "Creative", "Portfolio Ready"],
    },
    {
      id: "executive",
      name: "Executive Elite",
      description: "Sophisticated layout for senior positions",
      preview: "/executive-resume-template-elegant.jpg",
      features: ["Executive Level", "Sophisticated", "Leadership Focus"],
    },
    {
      id: "tech",
      name: "Tech Innovator",
      description: "Modern tech-focused design with skill highlights",
      preview: "/tech-resume-template-with-skills-section.jpg",
      features: ["Tech Focused", "Skills Highlight", "Modern"],
    },
  ]

  const exportFormats = [
    { id: "pdf", name: "PDF", icon: FileText, description: "Best for applications" },
    { id: "png", name: "PNG", icon: ImageIcon, description: "For social media" },
    { id: "docx", name: "Word", icon: FileText, description: "Editable format" },
  ]

  const handleExport = async () => {
    setIsExporting(true)

    // Simulate export process
    await new Promise((resolve) => setTimeout(resolve, 2000))

    // Create download link
    const blob = new Blob([`Exported resume: ${fileName} using ${selectedTemplate} template`], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `${fileName.replace(".pdf", "")}_${selectedTemplate}.${exportFormat}`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)

    setIsExporting(false)
  }

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <Download className="w-4 h-4 mr-2" />
          Export Resume
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Export & Templates</DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="templates" className="space-y-6">
          <TabsList>
            <TabsTrigger value="templates">Templates</TabsTrigger>
            <TabsTrigger value="export">Export Options</TabsTrigger>
            <TabsTrigger value="improvements">AI Improvements</TabsTrigger>
          </TabsList>

          <TabsContent value="templates" className="space-y-6">
            <div>
              <h3 className="font-semibold mb-4">Choose Your Template</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {templates.map((template) => (
                  <Card
                    key={template.id}
                    className={`p-4 cursor-pointer transition-all ${
                      selectedTemplate === template.id ? "ring-2 ring-primary bg-primary/5" : "hover:shadow-md"
                    }`}
                    onClick={() => setSelectedTemplate(template.id)}
                  >
                    <div className="flex gap-4">
                      <img
                        src={template.preview || "/placeholder.svg"}
                        alt={template.name}
                        className="w-20 h-28 object-cover rounded border"
                      />
                      <div className="flex-1">
                        <h4 className="font-semibold mb-1">{template.name}</h4>
                        <p className="text-sm text-muted-foreground mb-3">{template.description}</p>
                        <div className="flex flex-wrap gap-1">
                          {template.features.map((feature) => (
                            <Badge key={feature} variant="secondary" className="text-xs">
                              {feature}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="export" className="space-y-6">
            <div>
              <h3 className="font-semibold mb-4">Export Format</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                {exportFormats.map((format) => (
                  <Card
                    key={format.id}
                    className={`p-4 cursor-pointer transition-all ${
                      exportFormat === format.id ? "ring-2 ring-primary bg-primary/5" : "hover:shadow-md"
                    }`}
                    onClick={() => setExportFormat(format.id)}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gradient-primary rounded-lg flex items-center justify-center">
                        <format.icon className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <h4 className="font-semibold">{format.name}</h4>
                        <p className="text-sm text-muted-foreground">{format.description}</p>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>

              <Card className="p-4 bg-muted/50">
                <h4 className="font-semibold mb-2">Export Preview</h4>
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <div className="flex items-center gap-2">
                    <Layout className="w-4 h-4" />
                    Template: {templates.find((t) => t.id === selectedTemplate)?.name}
                  </div>
                  <div className="flex items-center gap-2">
                    <FileText className="w-4 h-4" />
                    Format: {exportFormat.toUpperCase()}
                  </div>
                  <div className="flex items-center gap-2">
                    <Zap className="w-4 h-4" />
                    Score: {analysisData.overallScore}/100
                  </div>
                </div>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="improvements" className="space-y-6">
            <div>
              <h3 className="font-semibold mb-4">AI-Powered Improvements</h3>
              <div className="space-y-4">
                <Card className="p-4">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-green-500 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Zap className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold mb-1">Auto-Enhanced Content</h4>
                      <p className="text-sm text-muted-foreground mb-2">
                        Apply AI suggestions to strengthen your resume before export
                      </p>
                      <div className="space-y-2">
                        {analysisData.improvements.slice(0, 3).map((improvement: string, index: number) => (
                          <div key={index} className="flex items-center gap-2 text-sm">
                            <div className="w-1.5 h-1.5 bg-green-500 rounded-full" />
                            {improvement}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </Card>

                <Card className="p-4">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Palette className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold mb-1">Smart Formatting</h4>
                      <p className="text-sm text-muted-foreground">
                        Automatically optimize layout, spacing, and typography for maximum impact
                      </p>
                    </div>
                  </div>
                </Card>

                <Card className="p-4">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 bg-purple-500 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Share2 className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold mb-1">ATS Optimization</h4>
                      <p className="text-sm text-muted-foreground">
                        Ensure your resume passes through Applicant Tracking Systems
                      </p>
                    </div>
                  </div>
                </Card>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        <div className="flex justify-between items-center pt-4 border-t">
          <div className="text-sm text-muted-foreground">
            Exporting: {fileName} → {selectedTemplate} template
          </div>
          <Button onClick={handleExport} disabled={isExporting} className="min-w-[120px]">
            {isExporting ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2" />
                Exporting...
              </>
            ) : (
              <>
                <Download className="w-4 h-4 mr-2" />
                Export Now
              </>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
