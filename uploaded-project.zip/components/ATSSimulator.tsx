"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Bot, CheckCircle, AlertTriangle, XCircle } from "lucide-react"

interface ATSSimulatorProps {
  resumeContent: string
  onClose: () => void
}

export function ATSSimulator({ resumeContent, onClose }: ATSSimulatorProps) {
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [results, setResults] = useState<any>(null)

  const runATSSimulation = async () => {
    setIsAnalyzing(true)

    // Simulate ATS analysis
    await new Promise((resolve) => setTimeout(resolve, 3000))

    setResults({
      overallCompatibility: 85,
      parsedCorrectly: 92,
      keywordMatch: 78,
      formatScore: 88,
      issues: [
        { type: "warning", message: "Missing contact information section header" },
        { type: "error", message: "Skills section not properly formatted" },
        { type: "info", message: "Consider adding more industry keywords" },
      ],
      recommendations: [
        "Add clear section headers (Experience, Education, Skills)",
        "Use standard date formats (MM/YYYY)",
        "Include more relevant keywords for your target role",
        "Avoid complex formatting and graphics",
      ],
    })

    setIsAnalyzing(false)
  }

  return (
    <div className="min-h-screen bg-background p-4 lg:p-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-6">
          <Button variant="outline" onClick={onClose}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <div>
            <h1 className="text-2xl font-bold">ATS Simulator</h1>
            <p className="text-muted-foreground">Test how Applicant Tracking Systems will parse your resume</p>
          </div>
        </div>

        {!results && !isAnalyzing && (
          <Card className="p-8 text-center">
            <div className="w-16 h-16 mx-auto mb-4 bg-gradient-primary rounded-full flex items-center justify-center">
              <Bot className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-xl font-semibold mb-2">ATS Compatibility Check</h2>
            <p className="text-muted-foreground mb-6">Simulate how major ATS systems will read and parse your resume</p>
            <Button onClick={runATSSimulation} size="lg">
              Run ATS Simulation
            </Button>
          </Card>
        )}

        {isAnalyzing && (
          <Card className="p-8 text-center">
            <div className="w-16 h-16 mx-auto mb-4 bg-gradient-primary rounded-full flex items-center justify-center">
              <Bot className="w-8 h-8 text-white animate-pulse" />
            </div>
            <h2 className="text-xl font-semibold mb-2">Analyzing Your Resume</h2>
            <p className="text-muted-foreground mb-6">Running through multiple ATS systems...</p>
            <Progress value={65} className="max-w-md mx-auto" />
          </Card>
        )}

        {results && (
          <div className="space-y-6">
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">ATS Compatibility Score</h3>
              <div className="text-center mb-4">
                <div className="text-4xl font-bold text-green-600 mb-2">{results.overallCompatibility}%</div>
                <p className="text-muted-foreground">Overall Compatibility</p>
              </div>
              <Progress value={results.overallCompatibility} className="h-3" />
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="p-4">
                <h4 className="font-semibold mb-2">Parsing Accuracy</h4>
                <div className="text-2xl font-bold text-blue-600 mb-1">{results.parsedCorrectly}%</div>
                <Progress value={results.parsedCorrectly} className="h-2" />
              </Card>

              <Card className="p-4">
                <h4 className="font-semibold mb-2">Keyword Match</h4>
                <div className="text-2xl font-bold text-yellow-600 mb-1">{results.keywordMatch}%</div>
                <Progress value={results.keywordMatch} className="h-2" />
              </Card>

              <Card className="p-4">
                <h4 className="font-semibold mb-2">Format Score</h4>
                <div className="text-2xl font-bold text-green-600 mb-1">{results.formatScore}%</div>
                <Progress value={results.formatScore} className="h-2" />
              </Card>
            </div>

            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Issues Found</h3>
              <div className="space-y-3">
                {results.issues.map((issue: any, index: number) => (
                  <div key={index} className="flex items-start gap-3">
                    {issue.type === "error" && <XCircle className="w-5 h-5 text-red-500 mt-0.5" />}
                    {issue.type === "warning" && <AlertTriangle className="w-5 h-5 text-yellow-500 mt-0.5" />}
                    {issue.type === "info" && <CheckCircle className="w-5 h-5 text-blue-500 mt-0.5" />}
                    <div>
                      <Badge
                        variant={
                          issue.type === "error" ? "destructive" : issue.type === "warning" ? "secondary" : "default"
                        }
                      >
                        {issue.type.toUpperCase()}
                      </Badge>
                      <p className="text-sm mt-1">{issue.message}</p>
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-4">Recommendations</h3>
              <div className="space-y-2">
                {results.recommendations.map((rec: string, index: number) => (
                  <div key={index} className="flex items-start gap-2">
                    <div className="w-1.5 h-1.5 bg-blue-500 rounded-full mt-2 flex-shrink-0" />
                    <p className="text-sm">{rec}</p>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}
