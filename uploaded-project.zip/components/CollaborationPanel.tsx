"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { MessageSquare, Send, Users, Eye, Edit3, Clock } from "lucide-react"

interface Comment {
  id: string
  user: string
  content: string
  timestamp: Date
  section?: string
}

interface CollaborationPanelProps {
  isOpen: boolean
  onClose: () => void
  analysisData: any
}

export function CollaborationPanel({ isOpen, onClose, analysisData }: CollaborationPanelProps) {
  const [comments, setComments] = useState<Comment[]>([])
  const [newComment, setNewComment] = useState("")
  const [activeUsers, setActiveUsers] = useState([
    { name: "Sarah Chen", status: "viewing", color: "bg-blue-500" },
    { name: "Mike Rodriguez", status: "editing", color: "bg-green-500" },
  ])

  // Mock real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      // Simulate user activity updates
      setActiveUsers((prev) =>
        prev.map((user) => ({
          ...user,
          status: Math.random() > 0.7 ? "editing" : "viewing",
        })),
      )
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  const addComment = () => {
    if (newComment.trim()) {
      const comment: Comment = {
        id: Date.now().toString(),
        user: "You",
        content: newComment,
        timestamp: new Date(),
      }
      setComments([...comments, comment])
      setNewComment("")
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed right-0 top-0 h-full w-80 bg-background border-l shadow-lg z-50 flex flex-col">
      {/* Header */}
      <div className="p-4 border-b">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-semibold flex items-center gap-2">
            <Users className="w-4 h-4" />
            Collaboration
          </h3>
          <Button variant="ghost" size="sm" onClick={onClose}>
            ×
          </Button>
        </div>

        {/* Active Users */}
        <div className="space-y-2">
          <p className="text-xs text-muted-foreground">Active now ({activeUsers.length})</p>
          <div className="flex flex-wrap gap-2">
            {activeUsers.map((user, index) => (
              <div key={index} className="flex items-center gap-2 text-xs">
                <Avatar className="w-6 h-6">
                  <AvatarFallback className={`${user.color} text-white text-xs`}>
                    {user.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                <span className="text-muted-foreground">{user.name}</span>
                <Badge variant="outline" className="text-xs px-1 py-0">
                  {user.status === "editing" ? (
                    <>
                      <Edit3 className="w-3 h-3 mr-1" />
                      Editing
                    </>
                  ) : (
                    <>
                      <Eye className="w-3 h-3 mr-1" />
                      Viewing
                    </>
                  )}
                </Badge>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Comments Section */}
      <div className="flex-1 flex flex-col">
        <div className="p-4 border-b">
          <h4 className="font-medium text-sm mb-3 flex items-center gap-2">
            <MessageSquare className="w-4 h-4" />
            Comments & Feedback
          </h4>
        </div>

        {/* Comments List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {comments.length === 0 ? (
            <div className="text-center text-muted-foreground text-sm py-8">
              <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-50" />
              No comments yet. Start the conversation!
            </div>
          ) : (
            comments.map((comment) => (
              <Card key={comment.id} className="p-3">
                <div className="flex items-start gap-2">
                  <Avatar className="w-6 h-6">
                    <AvatarFallback className="bg-gradient-primary text-white text-xs">
                      {comment.user[0]}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium text-sm">{comment.user}</span>
                      <span className="text-xs text-muted-foreground flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {comment.timestamp.toLocaleTimeString()}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground">{comment.content}</p>
                  </div>
                </div>
              </Card>
            ))
          )}
        </div>

        {/* Add Comment */}
        <div className="p-4 border-t">
          <div className="flex gap-2">
            <Input
              placeholder="Add a comment..."
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && addComment()}
              className="text-sm"
            />
            <Button size="sm" onClick={addComment}>
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
