"use client"

import { useState, useCallback } from "react"
import { useDropzone } from "react-dropzone"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Upload, FileText, AlertCircle } from "lucide-react"

interface ResumeUploadProps {
  onFileUploaded: (file: File, content: string) => void
}

export function ResumeUpload({ onFileUploaded }: ResumeUploadProps) {
  const [isUploading, setIsUploading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const onDrop = useCallback(
    async (acceptedFiles: File[]) => {
      const file = acceptedFiles[0]
      if (!file) return

      setIsUploading(true)
      setError(null)

      try {
        const text = await file.text()
        onFileUploaded(file, text)
      } catch (err) {
        setError("Failed to read file. Please try again.")
      } finally {
        setIsUploading(false)
      }
    },
    [onFileUploaded],
  )

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      "application/pdf": [".pdf"],
      "application/msword": [".doc"],
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document": [".docx"],
      "text/plain": [".txt"],
    },
    maxFiles: 1,
    maxSize: 10 * 1024 * 1024, // 10MB
  })

  return (
    <Card className="p-8 bg-gradient-card shadow-soft border-0">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold mb-2">Upload Your Resume</h2>
        <p className="text-muted-foreground">
          Upload your resume to get AI-powered insights and optimization suggestions
        </p>
      </div>

      <div
        {...getRootProps()}
        className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors ${
          isDragActive ? "border-primary bg-primary/5" : "border-muted-foreground/25 hover:border-primary/50"
        }`}
      >
        <input {...getInputProps()} />

        <div className="flex flex-col items-center gap-4">
          <div className="w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center">
            {isUploading ? (
              <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <Upload className="w-8 h-8 text-white" />
            )}
          </div>

          {isUploading ? (
            <div>
              <p className="text-lg font-semibold">Processing your resume...</p>
              <p className="text-muted-foreground">This may take a few moments</p>
            </div>
          ) : isDragActive ? (
            <div>
              <p className="text-lg font-semibold">Drop your resume here</p>
              <p className="text-muted-foreground">Release to upload</p>
            </div>
          ) : (
            <div>
              <p className="text-lg font-semibold">Drag & drop your resume here</p>
              <p className="text-muted-foreground mb-4">or click to browse files</p>
              <Button variant="outline">
                <FileText className="w-4 h-4 mr-2" />
                Choose File
              </Button>
            </div>
          )}
        </div>
      </div>

      {error && (
        <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-red-700">
          <AlertCircle className="w-4 h-4" />
          {error}
        </div>
      )}

      <div className="mt-6 text-center text-sm text-muted-foreground">
        <p>Supported formats: PDF, DOC, DOCX, TXT</p>
        <p>Maximum file size: 10MB</p>
      </div>
    </Card>
  )
}
