"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { TrendingUp, Target, Eye, Award, ArrowUp, ArrowDown, Minus } from "lucide-react"
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
} from "recharts"

interface AnalyticsDashboardProps {
  analysisData: any
  userInfo: any
  fileName: string
}

export function AnalyticsDashboard({ analysisData, userInfo, fileName }: AnalyticsDashboardProps) {
  const [timeRange, setTimeRange] = useState("7d")

  // Mock analytics data
  const performanceData = [
    { date: "Mon", score: 72, views: 45, applications: 3 },
    { date: "Tue", score: 75, views: 52, applications: 4 },
    { date: "Wed", score: 78, views: 48, applications: 2 },
    { date: "Thu", score: 78, views: 61, applications: 5 },
    { date: "Fri", score: 82, views: 58, applications: 6 },
    { date: "Sat", score: 85, views: 34, applications: 2 },
    { date: "Sun", score: 87, views: 29, applications: 1 },
  ]

  const skillsRadarData = [
    { skill: "Technical", current: 85, target: 95 },
    { skill: "Leadership", current: 70, target: 85 },
    { skill: "Communication", current: 75, target: 90 },
    { skill: "Problem Solving", current: 90, target: 95 },
    { skill: "Teamwork", current: 80, target: 88 },
    { skill: "Innovation", current: 65, target: 85 },
  ]

  const industryBenchmark = [
    { category: "Software Engineer", yourScore: 87, average: 72, top10: 92 },
    { category: "Senior Developer", yourScore: 84, average: 75, top10: 89 },
    { category: "Tech Lead", yourScore: 78, average: 70, top10: 85 },
    { category: "Product Manager", yourScore: 71, average: 68, top10: 82 },
  ]

  const keywordDensity = [
    { keyword: "JavaScript", count: 12, optimal: 8, status: "high" },
    { keyword: "React", count: 8, optimal: 6, status: "optimal" },
    { keyword: "Leadership", count: 3, optimal: 5, status: "low" },
    { keyword: "Python", count: 6, optimal: 7, status: "optimal" },
    { keyword: "AWS", count: 4, optimal: 5, status: "low" },
  ]

  const COLORS = ["#8b5cf6", "#06b6d4", "#10b981", "#f59e0b", "#ef4444"]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Analytics Dashboard</h2>
          <p className="text-muted-foreground">
            Advanced insights for {fileName} • {userInfo.targetRole}
          </p>
        </div>
        <div className="flex gap-2">
          {["7d", "30d", "90d"].map((range) => (
            <Button
              key={range}
              variant={timeRange === range ? "default" : "outline"}
              size="sm"
              onClick={() => setTimeRange(range)}
            >
              {range}
            </Button>
          ))}
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Overall Score</p>
              <p className="text-2xl font-bold">{analysisData.overallScore}</p>
            </div>
            <div className="w-10 h-10 bg-gradient-primary rounded-lg flex items-center justify-center">
              <Award className="w-5 h-5 text-white" />
            </div>
          </div>
          <div className="flex items-center gap-1 mt-2">
            <ArrowUp className="w-4 h-4 text-green-500" />
            <span className="text-sm text-green-500">+5 from last week</span>
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Profile Views</p>
              <p className="text-2xl font-bold">327</p>
            </div>
            <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center">
              <Eye className="w-5 h-5 text-white" />
            </div>
          </div>
          <div className="flex items-center gap-1 mt-2">
            <ArrowUp className="w-4 h-4 text-green-500" />
            <span className="text-sm text-green-500">+12% this week</span>
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Applications</p>
              <p className="text-2xl font-bold">23</p>
            </div>
            <div className="w-10 h-10 bg-green-500 rounded-lg flex items-center justify-center">
              <Target className="w-5 h-5 text-white" />
            </div>
          </div>
          <div className="flex items-center gap-1 mt-2">
            <Minus className="w-4 h-4 text-yellow-500" />
            <span className="text-sm text-yellow-500">No change</span>
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Response Rate</p>
              <p className="text-2xl font-bold">18%</p>
            </div>
            <div className="w-10 h-10 bg-purple-500 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-white" />
            </div>
          </div>
          <div className="flex items-center gap-1 mt-2">
            <ArrowDown className="w-4 h-4 text-red-500" />
            <span className="text-sm text-red-500">-3% this week</span>
          </div>
        </Card>
      </div>

      <Tabs defaultValue="performance" className="space-y-4">
        <TabsList>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="skills">Skills Analysis</TabsTrigger>
          <TabsTrigger value="keywords">Keywords</TabsTrigger>
          <TabsTrigger value="benchmark">Benchmarks</TabsTrigger>
        </TabsList>

        <TabsContent value="performance" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="p-6">
              <h3 className="font-semibold mb-4">Score Progression</h3>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={performanceData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Line
                    type="monotone"
                    dataKey="score"
                    stroke="#8b5cf6"
                    strokeWidth={3}
                    dot={{ fill: "#8b5cf6", strokeWidth: 2, r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </Card>

            <Card className="p-6">
              <h3 className="font-semibold mb-4">Application Activity</h3>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={performanceData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="applications" fill="#10b981" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="skills" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="p-6">
              <h3 className="font-semibold mb-4">Skills Radar</h3>
              <ResponsiveContainer width="100%" height={300}>
                <RadarChart data={skillsRadarData}>
                  <PolarGrid />
                  <PolarAngleAxis dataKey="skill" />
                  <PolarRadiusAxis angle={90} domain={[0, 100]} />
                  <Radar name="Current" dataKey="current" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.3} />
                  <Radar name="Target" dataKey="target" stroke="#06b6d4" fill="#06b6d4" fillOpacity={0.1} />
                  <Tooltip />
                </RadarChart>
              </ResponsiveContainer>
            </Card>

            <Card className="p-6">
              <h3 className="font-semibold mb-4">Skill Gaps</h3>
              <div className="space-y-4">
                {skillsRadarData.map((skill, index) => {
                  const gap = skill.target - skill.current
                  return (
                    <div key={index} className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>{skill.skill}</span>
                        <span className="text-muted-foreground">
                          {skill.current}/{skill.target}
                        </span>
                      </div>
                      <Progress value={(skill.current / skill.target) * 100} className="h-2" />
                      {gap > 10 && (
                        <Badge variant="outline" className="text-xs">
                          Focus area: +{gap} points needed
                        </Badge>
                      )}
                    </div>
                  )
                })}
              </div>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="keywords" className="space-y-4">
          <Card className="p-6">
            <h3 className="font-semibold mb-4">Keyword Optimization</h3>
            <div className="space-y-4">
              {keywordDensity.map((item, index) => (
                <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <span className="font-medium">{item.keyword}</span>
                    <Badge
                      variant={
                        item.status === "optimal" ? "default" : item.status === "high" ? "destructive" : "secondary"
                      }
                    >
                      {item.status}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-sm text-muted-foreground">
                      {item.count}/{item.optimal} mentions
                    </div>
                    <Progress value={(item.count / item.optimal) * 100} className="w-20 h-2" />
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="benchmark" className="space-y-4">
          <Card className="p-6">
            <h3 className="font-semibold mb-4">Industry Benchmarks</h3>
            <div className="space-y-6">
              {industryBenchmark.map((item, index) => (
                <div key={index} className="space-y-3">
                  <div className="flex justify-between items-center">
                    <h4 className="font-medium">{item.category}</h4>
                    <div className="flex gap-4 text-sm">
                      <span className="text-muted-foreground">
                        You: <span className="font-semibold text-foreground">{item.yourScore}</span>
                      </span>
                      <span className="text-muted-foreground">Avg: {item.average}</span>
                      <span className="text-muted-foreground">Top 10%: {item.top10}</span>
                    </div>
                  </div>
                  <div className="relative">
                    <Progress value={(item.yourScore / 100) * 100} className="h-3" />
                    <div
                      className="absolute top-0 w-1 h-3 bg-yellow-500 rounded"
                      style={{ left: `${item.average}%` }}
                    />
                    <div className="absolute top-0 w-1 h-3 bg-green-500 rounded" style={{ left: `${item.top10}%` }} />
                  </div>
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>0</span>
                    <span>Industry Average</span>
                    <span>Top 10%</span>
                    <span>100</span>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
