"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Target, TrendingUp, AlertCircle } from "lucide-react"

interface JobDescriptionMatcherProps {
  resumeContent: string
  onClose: () => void
}

export function JobDescriptionMatcher({ resumeContent, onClose }: JobDescriptionMatcherProps) {
  const [jobDescription, setJobDescription] = useState("")
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [results, setResults] = useState<any>(null)

  const analyzeMatch = async () => {
    if (!jobDescription.trim()) return

    setIsAnalyzing(true)

    // Simulate job matching analysis
    await new Promise((resolve) => setTimeout(resolve, 2500))

    setResults({
      overallMatch: 76,
      keywordMatches: [
        { keyword: "JavaScript", inResume: true, inJob: true, importance: "high" },
        { keyword: "React", inResume: true, inJob: true, importance: "high" },
        { keyword: "Node.js", inResume: true, inJob: true, importance: "medium" },
        { keyword: "TypeScript", inResume: false, inJob: true, importance: "high" },
        { keyword: "AWS", inResume: true, inJob: true, importance: "medium" },
        { keyword: "Docker", inResume: false, inJob: true, importance: "medium" },
      ],
      missingSkills: ["TypeScript", "Docker", "Kubernetes", "GraphQL"],
      strongMatches: ["JavaScript", "React", "Node.js", "AWS", "Agile"],
      recommendations: [
        "Add TypeScript experience to your skills section",
        "Include Docker containerization projects",
        "Highlight your React expertise more prominently",
        "Add specific AWS services you've worked with",
      ],
    })

    setIsAnalyzing(false)
  }

  return (
    <div className="min-h-screen bg-background p-4 lg:p-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-6">
          <Button variant="outline" onClick={onClose}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <div>
            <h1 className="text-2xl font-bold">Job Description Matcher</h1>
            <p className="text-muted-foreground">Compare your resume against specific job requirements</p>
          </div>
        </div>

        <div className="space-y-6">
          <Card className="p-6">
            <Label htmlFor="jobDescription" className="text-lg font-semibold mb-4 block">
              Paste Job Description
            </Label>
            <Textarea
              id="jobDescription"
              value={jobDescription}
              onChange={(e) => setJobDescription(e.target.value)}
              placeholder="Paste the job description you want to match against..."
              rows={8}
              className="mb-4"
            />
            <Button onClick={analyzeMatch} disabled={!jobDescription.trim() || isAnalyzing} className="w-full">
              {isAnalyzing ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2" />
                  Analyzing Match...
                </>
              ) : (
                <>
                  <Target className="w-4 h-4 mr-2" />
                  Analyze Job Match
                </>
              )}
            </Button>
          </Card>

          {results && (
            <div className="space-y-6">
              <Card className="p-6">
                <h3 className="text-lg font-semibold mb-4">Match Score</h3>
                <div className="text-center mb-4">
                  <div className="text-4xl font-bold text-blue-600 mb-2">{results.overallMatch}%</div>
                  <p className="text-muted-foreground">Overall Job Match</p>
                </div>
                <Progress value={results.overallMatch} className="h-3" />
              </Card>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="p-6">
                  <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-green-600" />
                    Strong Matches
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {results.strongMatches.map((skill: string, index: number) => (
                      <Badge key={index} variant="default" className="bg-green-100 text-green-800">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </Card>

                <Card className="p-6">
                  <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                    <AlertCircle className="w-5 h-5 text-red-600" />
                    Missing Skills
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {results.missingSkills.map((skill: string, index: number) => (
                      <Badge key={index} variant="destructive">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </Card>
              </div>

              <Card className="p-6">
                <h3 className="text-lg font-semibold mb-4">Keyword Analysis</h3>
                <div className="space-y-3">
                  {results.keywordMatches.map((match: any, index: number) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <span className="font-medium">{match.keyword}</span>
                        <Badge variant={match.inResume && match.inJob ? "default" : "secondary"}>
                          {match.inResume && match.inJob ? "Match" : match.inResume ? "In Resume" : "Missing"}
                        </Badge>
                        <Badge variant={match.importance === "high" ? "destructive" : "secondary"}>
                          {match.importance} priority
                        </Badge>
                      </div>
                      <div className="text-sm text-muted-foreground">{match.inResume && match.inJob ? "✓" : "✗"}</div>
                    </div>
                  ))}
                </div>
              </Card>

              <Card className="p-6">
                <h3 className="text-lg font-semibold mb-4">Recommendations</h3>
                <div className="space-y-2">
                  {results.recommendations.map((rec: string, index: number) => (
                    <div key={index} className="flex items-start gap-2">
                      <div className="w-1.5 h-1.5 bg-blue-500 rounded-full mt-2 flex-shrink-0" />
                      <p className="text-sm">{rec}</p>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
