"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Share2, Copy, Mail, MessageSquare, Users, Link } from "lucide-react"
import { Card } from "@/components/ui/card"

interface ShareDialogProps {
  analysisData: any
  fileName: string
  userInfo: any
}

export function ShareDialog({ analysisData, fileName, userInfo }: ShareDialogProps) {
  const [shareUrl, setShareUrl] = useState("")
  const [collaborators, setCollaborators] = useState<string[]>([])
  const [newCollaborator, setNewCollaborator] = useState("")
  const [shareNote, setShareNote] = useState("")
  const [shareMode, setShareMode] = useState<"view" | "comment" | "edit">("view")

  const generateShareUrl = () => {
    const shareId = Math.random().toString(36).substring(2, 15)
    const url = `${window.location.origin}/shared/${shareId}`
    setShareUrl(url)
  }

  const copyToClipboard = () => {
    navigator.clipboard.writeText(shareUrl)
  }

  const addCollaborator = () => {
    if (newCollaborator && !collaborators.includes(newCollaborator)) {
      setCollaborators([...collaborators, newCollaborator])
      setNewCollaborator("")
    }
  }

  const removeCollaborator = (email: string) => {
    setCollaborators(collaborators.filter((c) => c !== email))
  }

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <Share2 className="w-4 h-4 mr-2" />
          Share Analysis
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Share Resume Analysis</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Share Summary */}
          <Card className="p-4 bg-muted/50">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-8 h-8 bg-gradient-primary rounded-lg flex items-center justify-center">
                <Users className="w-4 h-4 text-white" />
              </div>
              <div>
                <h3 className="font-semibold">{fileName}</h3>
                <p className="text-sm text-muted-foreground">
                  Score: {analysisData.overallScore}/100 • {userInfo.targetRole}
                </p>
              </div>
            </div>
          </Card>

          {/* Share Mode */}
          <div>
            <Label className="text-sm font-medium mb-3 block">Access Level</Label>
            <div className="flex gap-2">
              <Button
                variant={shareMode === "view" ? "default" : "outline"}
                size="sm"
                onClick={() => setShareMode("view")}
              >
                View Only
              </Button>
              <Button
                variant={shareMode === "comment" ? "default" : "outline"}
                size="sm"
                onClick={() => setShareMode("comment")}
              >
                <MessageSquare className="w-4 h-4 mr-1" />
                Comment
              </Button>
              <Button
                variant={shareMode === "edit" ? "default" : "outline"}
                size="sm"
                onClick={() => setShareMode("edit")}
              >
                Full Edit
              </Button>
            </div>
          </div>

          {/* Collaborators */}
          <div>
            <Label className="text-sm font-medium mb-3 block">Invite Collaborators</Label>
            <div className="flex gap-2 mb-3">
              <Input
                placeholder="Enter email address"
                value={newCollaborator}
                onChange={(e) => setNewCollaborator(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && addCollaborator()}
              />
              <Button onClick={addCollaborator} size="sm">
                <Mail className="w-4 h-4 mr-1" />
                Invite
              </Button>
            </div>

            {collaborators.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {collaborators.map((email) => (
                  <Badge key={email} variant="secondary" className="px-3 py-1">
                    {email}
                    <button
                      onClick={() => removeCollaborator(email)}
                      className="ml-2 text-muted-foreground hover:text-foreground"
                    >
                      ×
                    </button>
                  </Badge>
                ))}
              </div>
            )}
          </div>

          {/* Share Note */}
          <div>
            <Label htmlFor="shareNote" className="text-sm font-medium mb-2 block">
              Add a Note (Optional)
            </Label>
            <Textarea
              id="shareNote"
              placeholder="Add context or specific feedback requests..."
              value={shareNote}
              onChange={(e) => setShareNote(e.target.value)}
              rows={3}
            />
          </div>

          {/* Generate Link */}
          <div>
            <div className="flex gap-2 mb-3">
              <Button onClick={generateShareUrl} className="flex-1">
                <Link className="w-4 h-4 mr-2" />
                Generate Share Link
              </Button>
              {shareUrl && (
                <Button variant="outline" onClick={copyToClipboard}>
                  <Copy className="w-4 h-4" />
                </Button>
              )}
            </div>

            {shareUrl && (
              <div className="p-3 bg-muted rounded-lg">
                <p className="text-sm font-mono break-all">{shareUrl}</p>
              </div>
            )}
          </div>

          {/* Real-time Status */}
          <Card className="p-4 border-dashed">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
              Real-time collaboration enabled • Changes sync instantly
            </div>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  )
}
