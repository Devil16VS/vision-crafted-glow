"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Eye, Download, Star, Zap, Layout, Palette } from "lucide-react"

interface TemplateGalleryProps {
  onSelectTemplate: (templateId: string) => void
}

export function TemplateGallery({ onSelectTemplate }: TemplateGalleryProps) {
  const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null)

  const templates = [
    {
      id: "modern-minimal",
      name: "Modern Minimal",
      category: "Professional",
      rating: 4.9,
      downloads: "12.3k",
      preview: "/modern-minimal-resume-template-clean.jpg",
      features: ["ATS Optimized", "Clean Design", "Professional"],
      description: "Perfect for corporate environments and traditional industries",
      colors: ["Blue", "Gray", "Black"],
    },
    {
      id: "creative-bold",
      name: "Creative Bold",
      category: "Creative",
      rating: 4.8,
      downloads: "8.7k",
      preview: "/creative-bold-resume-template-colorful.jpg",
      features: ["Eye-catching", "Creative", "Colorful"],
      description: "Stand out in creative fields with this vibrant design",
      colors: ["Purple", "Orange", "Teal"],
    },
    {
      id: "executive-elite",
      name: "Executive Elite",
      category: "Executive",
      rating: 4.9,
      downloads: "15.2k",
      preview: "/executive-resume-template-sophisticated-elegant.jpg",
      features: ["Executive Level", "Sophisticated", "Premium"],
      description: "Designed for C-level executives and senior management",
      colors: ["Navy", "Gold", "Charcoal"],
    },
    {
      id: "tech-innovator",
      name: "Tech Innovator",
      category: "Technology",
      rating: 4.7,
      downloads: "9.1k",
      preview: "/tech-resume-template-modern-skills-focused.jpg",
      features: ["Tech Focused", "Skills Highlight", "Modern"],
      description: "Optimized for software engineers and tech professionals",
      colors: ["Green", "Blue", "Dark"],
    },
    {
      id: "academic-scholar",
      name: "Academic Scholar",
      category: "Academic",
      rating: 4.6,
      downloads: "5.4k",
      preview: "/academic-resume-template-research-focused.jpg",
      features: ["Research Focus", "Publication Ready", "Academic"],
      description: "Tailored for researchers, professors, and academic positions",
      colors: ["Burgundy", "Gray", "White"],
    },
    {
      id: "startup-founder",
      name: "Startup Founder",
      category: "Entrepreneurial",
      rating: 4.8,
      downloads: "6.8k",
      preview: "/startup-founder-resume-template-entrepreneurial.jpg",
      features: ["Entrepreneurial", "Impact Focused", "Dynamic"],
      description: "Perfect for founders, entrepreneurs, and startup professionals",
      colors: ["Orange", "Blue", "Black"],
    },
  ]

  const categories = ["All", "Professional", "Creative", "Executive", "Technology", "Academic", "Entrepreneurial"]
  const [activeCategory, setActiveCategory] = useState("All")

  const filteredTemplates =
    activeCategory === "All" ? templates : templates.filter((t) => t.category === activeCategory)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Resume Templates</h2>
          <p className="text-muted-foreground">Professional templates designed by experts, optimized for ATS</p>
        </div>
      </div>

      {/* Category Filter */}
      <div className="flex flex-wrap gap-2">
        {categories.map((category) => (
          <Button
            key={category}
            variant={activeCategory === category ? "default" : "outline"}
            size="sm"
            onClick={() => setActiveCategory(category)}
          >
            {category}
          </Button>
        ))}
      </div>

      {/* Templates Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTemplates.map((template) => (
          <Card key={template.id} className="overflow-hidden hover:shadow-lg transition-shadow">
            <div className="relative">
              <img
                src={template.preview || "/placeholder.svg"}
                alt={template.name}
                className="w-full h-48 object-cover"
              />
              <div className="absolute top-2 right-2">
                <Badge variant="secondary" className="bg-white/90 text-black">
                  {template.category}
                </Badge>
              </div>
            </div>

            <div className="p-4">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-semibold">{template.name}</h3>
                <div className="flex items-center gap-1 text-sm text-muted-foreground">
                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  {template.rating}
                </div>
              </div>

              <p className="text-sm text-muted-foreground mb-3">{template.description}</p>

              <div className="flex flex-wrap gap-1 mb-3">
                {template.features.map((feature) => (
                  <Badge key={feature} variant="outline" className="text-xs">
                    {feature}
                  </Badge>
                ))}
              </div>

              <div className="flex items-center justify-between">
                <div className="text-sm text-muted-foreground">{template.downloads} downloads</div>
                <div className="flex gap-2">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm">
                        <Eye className="w-4 h-4" />
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl">
                      <DialogHeader>
                        <DialogTitle>{template.name} Preview</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <img
                          src={template.preview || "/placeholder.svg"}
                          alt={template.name}
                          className="w-full max-w-md mx-auto rounded-lg border"
                        />
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <h4 className="font-semibold mb-2">Features</h4>
                            <ul className="space-y-1">
                              {template.features.map((feature) => (
                                <li key={feature} className="flex items-center gap-2">
                                  <div className="w-1.5 h-1.5 bg-green-500 rounded-full" />
                                  {feature}
                                </li>
                              ))}
                            </ul>
                          </div>
                          <div>
                            <h4 className="font-semibold mb-2">Color Options</h4>
                            <div className="flex gap-2">
                              {template.colors.map((color) => (
                                <Badge key={color} variant="secondary" className="text-xs">
                                  {color}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </div>
                        <Button
                          onClick={() => {
                            onSelectTemplate(template.id)
                            setSelectedTemplate(template.id)
                          }}
                          className="w-full"
                        >
                          <Layout className="w-4 h-4 mr-2" />
                          Use This Template
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>

                  <Button
                    size="sm"
                    onClick={() => {
                      onSelectTemplate(template.id)
                      setSelectedTemplate(template.id)
                    }}
                  >
                    <Download className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* AI Template Generator */}
      <Card className="p-6 bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 bg-gradient-primary rounded-lg flex items-center justify-center flex-shrink-0">
            <Zap className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1">
            <h3 className="font-semibold mb-2">AI Template Generator</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Can't find the perfect template? Let our AI create a custom design based on your industry, role, and
              personal preferences.
            </p>
            <Button variant="outline">
              <Palette className="w-4 h-4 mr-2" />
              Generate Custom Template
            </Button>
          </div>
        </div>
      </Card>
    </div>
  )
}
