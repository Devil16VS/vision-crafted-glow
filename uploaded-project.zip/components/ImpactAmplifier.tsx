"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { ArrowLeft, Zap, Copy, RefreshCw } from "lucide-react"

interface ImpactAmplifierProps {
  resumeContent: string
  onClose: () => void
}

export function ImpactAmplifier({ resumeContent, onClose }: ImpactAmplifierProps) {
  const [inputText, setInputText] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)
  const [results, setResults] = useState<any>(null)

  const amplifyImpact = async () => {
    if (!inputText.trim()) return

    setIsGenerating(true)

    // Simulate impact amplification
    await new Promise((resolve) => setTimeout(resolve, 2000))

    setResults({
      original: inputText,
      enhanced: [
        "Spearheaded cross-functional development team of 8 engineers, delivering 3 high-impact features that increased user engagement by 45% and reduced customer churn by 23% over 6 months",
        "Led strategic development initiatives across 8-person engineering team, architecting and deploying 3 mission-critical features that drove 45% improvement in user engagement metrics and achieved 23% reduction in customer churn within 6-month timeline",
        "Orchestrated collaborative development efforts with 8 cross-functional engineers, successfully launching 3 revenue-driving features that boosted user engagement by 45% and decreased customer churn by 23%, exceeding quarterly targets by 15%",
      ],
      improvements: [
        "Added specific team size (8 engineers)",
        "Quantified impact with percentages (45%, 23%)",
        "Included timeline (6 months)",
        "Used stronger action verbs (spearheaded, orchestrated)",
        "Added context about exceeding targets",
      ],
    })

    setIsGenerating(false)
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
  }

  return (
    <div className="min-h-screen bg-background p-4 lg:p-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-6">
          <Button variant="outline" onClick={onClose}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <div>
            <h1 className="text-2xl font-bold">Impact Amplifier</h1>
            <p className="text-muted-foreground">Transform weak statements into powerful, quantified achievements</p>
          </div>
        </div>

        <div className="space-y-6">
          <Card className="p-6">
            <Label htmlFor="inputText" className="text-lg font-semibold mb-4 block">
              Enter Your Achievement or Experience
            </Label>
            <Textarea
              id="inputText"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Example: Led a team to develop new features that improved user experience"
              rows={4}
              className="mb-4"
            />
            <Button onClick={amplifyImpact} disabled={!inputText.trim() || isGenerating} className="w-full">
              {isGenerating ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2" />
                  Amplifying Impact...
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 mr-2" />
                  Amplify Impact
                </>
              )}
            </Button>
          </Card>

          {results && (
            <div className="space-y-6">
              <Card className="p-6">
                <h3 className="text-lg font-semibold mb-4">Original Statement</h3>
                <div className="p-4 bg-muted/50 rounded-lg">
                  <p className="text-sm">{results.original}</p>
                </div>
              </Card>

              <Card className="p-6">
                <h3 className="text-lg font-semibold mb-4">Enhanced Versions</h3>
                <div className="space-y-4">
                  {results.enhanced.map((version: string, index: number) => (
                    <div key={index} className="p-4 border rounded-lg">
                      <div className="flex items-start justify-between gap-4">
                        <p className="text-sm flex-1">{version}</p>
                        <Button variant="outline" size="sm" onClick={() => copyToClipboard(version)}>
                          <Copy className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>

              <Card className="p-6">
                <h3 className="text-lg font-semibold mb-4">Key Improvements Made</h3>
                <div className="space-y-2">
                  {results.improvements.map((improvement: string, index: number) => (
                    <div key={index} className="flex items-start gap-2">
                      <div className="w-1.5 h-1.5 bg-green-500 rounded-full mt-2 flex-shrink-0" />
                      <p className="text-sm">{improvement}</p>
                    </div>
                  ))}
                </div>
              </Card>

              <Card className="p-6 bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-gradient-primary rounded-lg flex items-center justify-center flex-shrink-0">
                    <RefreshCw className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2">Pro Tips for Impact Statements</h4>
                    <ul className="text-sm space-y-1 text-muted-foreground">
                      <li>• Start with strong action verbs (led, spearheaded, optimized)</li>
                      <li>• Include specific numbers and percentages</li>
                      <li>• Add context about team size and timeline</li>
                      <li>• Mention the business impact or outcome</li>
                      <li>• Use industry-relevant keywords</li>
                    </ul>
                  </div>
                </div>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
