import { type NextRequest, NextResponse } from "next/server"
import { generateObject } from "ai"
import { groq } from "@ai-sdk/groq"
import { z } from "zod"

const atsSimulationSchema = z.object({
  overallCompatibility: z.number().min(0).max(100),
  keywordMatches: z.array(
    z.object({
      keyword: z.string(),
      found: z.boolean(),
      frequency: z.number(),
      importance: z.enum(["high", "medium", "low"]),
    }),
  ),
  formatIssues: z.array(z.string()),
  recommendations: z.array(z.string()),
  atsScore: z.object({
    parsing: z.number().min(0).max(100),
    keywords: z.number().min(0).max(100),
    formatting: z.number().min(0).max(100),
  }),
})

export async function POST(request: NextRequest) {
  try {
    const { resumeContent, jobDescription } = await request.json()

    const { object: simulation } = await generateObject({
      model: groq("llama-3.3-70b-versatile"),
      schema: atsSimulationSchema,
      prompt: `
        You are an ATS (Applicant Tracking System) simulator. Analyze this resume as if you were a modern ATS system.
        
        Resume Content:
        ${resumeContent}
        
        ${jobDescription ? `Job Description: ${jobDescription}` : ""}
        
        Simulate how an ATS would process this resume:
        1. Overall compatibility score (0-100)
        2. Keyword analysis with frequency and importance
        3. Format issues that might cause parsing problems
        4. Specific recommendations to improve ATS compatibility
        5. Detailed scores for parsing, keywords, and formatting
        
        Focus on:
        - Standard section headers
        - Keyword density and relevance
        - File format compatibility
        - Font and formatting issues
        - Contact information parsing
        - Date format consistency
      `,
    })

    return NextResponse.json(simulation)
  } catch (error) {
    console.error("ATS simulation error:", error)
    return NextResponse.json({ error: "Failed to simulate ATS" }, { status: 500 })
  }
}
