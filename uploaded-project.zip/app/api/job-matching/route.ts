import { type NextRequest, NextResponse } from "next/server"
import { generateObject } from "ai"
import { groq } from "@ai-sdk/groq"
import { z } from "zod"

const jobMatchingSchema = z.object({
  matchScore: z.number().min(0).max(100),
  keywordAnalysis: z.array(
    z.object({
      keyword: z.string(),
      resumeFrequency: z.number(),
      jobFrequency: z.number(),
      match: z.boolean(),
      importance: z.enum(["critical", "high", "medium", "low"]),
    }),
  ),
  skillGaps: z.array(z.string()),
  strengths: z.array(z.string()),
  recommendations: z.array(z.string()),
  sections: z.object({
    technical: z.number().min(0).max(100),
    experience: z.number().min(0).max(100),
    education: z.number().min(0).max(100),
    soft_skills: z.number().min(0).max(100),
  }),
})

export async function POST(request: NextRequest) {
  try {
    const { resumeContent, jobDescription } = await request.json()

    if (!jobDescription) {
      return NextResponse.json({ error: "Job description is required" }, { status: 400 })
    }

    const { object: matching } = await generateObject({
      model: groq("llama-3.3-70b-versatile"),
      schema: jobMatchingSchema,
      prompt: `
        You are an expert job matching analyst. Compare this resume against the job description.
        
        Resume Content:
        ${resumeContent}
        
        Job Description:
        ${jobDescription}
        
        Provide detailed matching analysis:
        1. Overall match score (0-100)
        2. Keyword analysis comparing resume vs job requirements
        3. Skill gaps that need to be addressed
        4. Existing strengths that align well
        5. Specific recommendations to improve match
        6. Section-wise scoring for different areas
        
        Focus on:
        - Technical skills alignment
        - Experience relevance
        - Educational requirements
        - Soft skills mentioned
        - Industry-specific terminology
        - Required vs preferred qualifications
      `,
    })

    return NextResponse.json(matching)
  } catch (error) {
    console.error("Job matching error:", error)
    return NextResponse.json({ error: "Failed to match job description" }, { status: 500 })
  }
}
