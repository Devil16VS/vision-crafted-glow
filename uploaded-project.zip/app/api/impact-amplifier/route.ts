import { type NextRequest, NextResponse } from "next/server"
import { generateObject } from "ai"
import { groq } from "@ai-sdk/groq"
import { z } from "zod"

const impactAmplifierSchema = z.object({
  originalStatements: z.array(z.string()),
  amplifiedStatements: z.array(
    z.object({
      original: z.string(),
      improved: z.string(),
      reasoning: z.string(),
      impact: z.enum(["high", "medium", "low"]),
    }),
  ),
  suggestions: z.array(
    z.object({
      category: z.string(),
      recommendation: z.string(),
      example: z.string(),
    }),
  ),
  overallImprovement: z.number().min(0).max(100),
})

export async function POST(request: NextRequest) {
  try {
    const { resumeContent, targetRole } = await request.json()

    const { object: amplification } = await generateObject({
      model: groq("llama-3.3-70b-versatile"),
      schema: impactAmplifierSchema,
      prompt: `
        You are an expert resume writer specializing in quantifying achievements and amplifying impact.
        
        Resume Content:
        ${resumeContent}
        
        Target Role: ${targetRole || "General"}
        
        Transform weak statements into powerful, quantified achievements:
        1. Identify original weak statements
        2. Provide improved versions with metrics and impact
        3. Explain the reasoning behind each improvement
        4. Rate the impact level of each change
        5. Give category-specific suggestions with examples
        6. Provide overall improvement score
        
        Focus on:
        - Adding specific numbers, percentages, and metrics
        - Using strong action verbs
        - Highlighting business impact and results
        - Making achievements relevant to target role
        - Following the STAR method (Situation, Task, Action, Result)
        - Industry-specific terminology and metrics
      `,
    })

    return NextResponse.json(amplification)
  } catch (error) {
    console.error("Impact amplifier error:", error)
    return NextResponse.json({ error: "Failed to amplify impact" }, { status: 500 })
  }
}
