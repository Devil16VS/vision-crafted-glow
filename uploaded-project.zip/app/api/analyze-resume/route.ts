import { type NextRequest, NextResponse } from "next/server"
import { generateObject } from "ai"
import { groq } from "@ai-sdk/groq"
import { z } from "zod"

const analysisSchema = z.object({
  overallScore: z.number().min(0).max(100),
  strengths: z.array(z.string()).min(3).max(6),
  improvements: z.array(z.string()).min(3).max(6),
  keywords: z.array(z.string()).min(5).max(15),
  sections: z
    .array(
      z.object({
        name: z.string(),
        score: z.number().min(0).max(100),
        feedback: z.string(),
      }),
    )
    .min(4)
    .max(8),
})

export async function POST(request: NextRequest) {
  try {
    const { resumeContent, userInfo } = await request.json()

    if (!resumeContent || !userInfo) {
      return NextResponse.json({ error: "Resume content and user info are required" }, { status: 400 })
    }

    const { object: analysis } = await generateObject({
      model: groq("llama-3.3-70b-versatile"),
      schema: analysisSchema,
      prompt: `
        You are an expert resume analyst and career coach. Analyze this resume for a ${userInfo.targetRole} position.
        
        User Context:
        - Current Role: ${userInfo.currentRole}
        - Target Role: ${userInfo.targetRole}
        - Experience Level: ${userInfo.experience}
        - Location: ${userInfo.location}
        
        Resume Content:
        ${resumeContent}
        
        Provide a comprehensive analysis with:
        1. Overall score (0-100) based on ATS compatibility, content quality, and relevance
        2. 3-6 key strengths that make this resume stand out
        3. 3-6 specific improvements with actionable advice
        4. 5-15 relevant keywords for the target role
        5. Section-by-section analysis (Contact, Summary, Experience, Skills, Education, etc.)
        
        Focus on:
        - ATS optimization and keyword density
        - Quantified achievements and impact metrics
        - Relevance to target role
        - Professional formatting and clarity
        - Industry-specific requirements
        
        Be specific, actionable, and constructive in your feedback.
      `,
    })

    return NextResponse.json(analysis)
  } catch (error) {
    console.error("Resume analysis error:", error)
    return NextResponse.json({ error: "Failed to analyze resume" }, { status: 500 })
  }
}
